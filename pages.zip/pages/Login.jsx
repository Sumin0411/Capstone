import { Route, NavLink ,useNavigate, Routes } from "react-router-dom"
import React , {useState} from 'react';
import { StyleSheet, TextInput, Text, View, Button,SafeAreaView ,Image,TouchableOpacity} from 'react-native';
import MainImg from '../assets/images/main.png'
import { inputStyles ,btnStyles } from '../globalStyle'
import CustomBtn from '../components/CustomButton'
import styled from 'styled-components/native'

const styles = StyleSheet.create({
    common : {
        backgroundColor : '#FFFFFF',
        flex: 1
    },
    inputArea : {
        height : '43%',
    },
    btnArea : {
        height : '18%',
        marginLeft : 600,
        marginRight : 650,
    },
    logo: {
      width: 66,
      height: 58,
    },
    mgVtAuto : {
       marginTop : 'auto',
       marginBottom : 'auto',
    }
  });

function Login({navigation}){
    const [text, onChangeText] = useState('');
    const [number, onChangeNumber] = useState('');
  
    return(
        <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.common}>
                <View style={styles.inputArea}>
                    <View style={styles.mgVtAuto}>
                        <View style={inputStyles.wrap}> 
                            <Text style={[inputStyles.label, { fontSize: 40 }]}>첫 번째 질문.</Text>
                        </View>
                    
                        <View style={inputStyles.wrap}>
                            <Text style={[inputStyles.label, { fontSize: 25 }]}>아빠는 보통 여가시간에 무엇을 하나요? </Text>
                            <Text style={[inputStyles.label, { fontSize: 15, fontWeight: 'normal' }]}>#1번째 질문 Sep 07, 2023</Text>
                            <TextInput
                                style={[inputStyles.input, { paddingVertical: 20, backgroundColor: '#CCCCCC' }]}
                                placeholderTextColor="#FFFFFF"
                                onChangeText={onChangeNumber}
                                value={number}
                                placeholder="이곳을 눌러서 답변을 입력해주세요."
                            />
                            </View>
                     
                    </View>
                </View>
                <View style={styles.btnArea}>
                    <View style={styles.mgVtAuto}>
                        <CustomBtn
                            title={'등록하기'}
                            background={'#0d0000'}
                            fontColor={'#FFFFFF'}
                            onPress={() => navigation.push('Join')}
                            style={{ width: 10 }}
                            />
                    </View>
                </View>
                
            </View>
        </SafeAreaView>
    )
}

export default Login