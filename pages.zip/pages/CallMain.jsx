import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { Linking } from 'react-native';
import CustomButton from '../components/CustomButton';
import { NumberListData } from '../Data';
import MyModal from '../components/MyModal';
import { useSpeechRecognition } from "react-speech-kit";
// import NoiseCancellation from 'noise-cancellation-library';


const styles = StyleSheet.create({
  container: {
    flex: 0.9,
    justifyContent: 'center',
    alignItems: 'center',
  },
  MicImg: {
    width: 200,
    height: 200,
  },
  listeningText: {
    fontSize: 50,
    fontWeight: 'bold',
    marginTop: 10,
  },
  resultText: {
    fontSize: 40,
    fontStyle: 'italic',
    marginTop: 10,
  },
  contactContainer: {
    marginTop: 20,
  },
  contactText: {
    fontSize: 50,
    marginBottom: 5,
  },
});

function Main() {
  const [value, setValue] = useState(' 마이크를 누르세요 ');
  const { listen, listening, stop } = useSpeechRecognition({
    onResult: result => {
      setValue(result);
    }
  });

  const handleCallContact = (number) => {
    Linking.openURL(`tel:${number}`);
  }

  const filteredContacts = NumberListData.filter(contact => {
    const lowerCaseValue = value.toLowerCase();
    const lowerCaseName = contact.name.toLowerCase();
    return (
      contact.tag.some(tag => lowerCaseValue.includes(tag)) || lowerCaseName.includes(lowerCaseValue)
    );
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handleMicPress}>
        <Image source={require('../assets/images/mic.png')} style={styles.MicImg} />
      </TouchableOpacity>

      {/* 이외의 컴포넌트들 */}
      {listening && <Text style={styles.listeningText}>음성인식 중</Text>}
      <Text style={styles.resultText}>{value}</Text>

      {/* 필터링된 연락처 표시 */}
      <View style={styles.contactContainer}>
        {filteredContacts.map((contact, index) => (
          <TouchableOpacity key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }} onPress={() => handleCallContact(contact.number)}>
          {contact.photo && <Image source={imageMap[contact.photo]} style={{ width: 170, height: 170, marginRight: 10 }} />}
          <View>
            <Text style={styles.contactText}>{contact.name}</Text>
            <Text style={styles.contactText}>{contact.number}</Text>
          </View>
        </TouchableOpacity>
      ))}
      </View>
    </View>
  );
}
export default Main;
