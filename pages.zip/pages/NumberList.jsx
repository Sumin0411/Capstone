import { NumberListData } from "../Data"
import React from 'react';
import { StyleSheet, TextInput, Text, View, Button, SafeAreaView, Image, TouchableOpacity, Linking, ScrollView } from 'react-native';
import CustomBtn from '../components/CustomButton'

const imageMap = {
  icon: require('../assets/images/photo/icon.png'),
  photo01: require('../assets/images/photo/photo01.png'),
  photo02: require('../assets/images/photo/photo02.png'),
  photo03: require('../assets/images/photo/photo03.png'),
  photo04: require('../assets/images/photo/photo04.png'),
  photo05: require('../assets/images/photo/photo05.png'),
  photo06: require('../assets/images/photo/photo06.png'),
  photo07: require('../assets/images/photo/photo07.png'),
  photo08: require('../assets/images/photo/photo08.png'),
  photo09: require('../assets/images/photo/photo09.png'),
  photo10: require('../assets/images/photo/photo10.png'),
  photo11: require('../assets/images/photo/photo11.png'),
};

const styles = StyleSheet.create({
  itemWrap: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    margin: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 10,
  },
  img: {
    width: 100,
    height: 100,
  },
  leftArea: {
    width: 100,
    marginRight: 10,
    alignItems: 'center',
  },
  rightArea: {
    flex: 1,
  },
  labelWrap: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  label: {
    minWidth: 60,
    fontWeight: 'bold',
    fontSize: 16,
  },
  value: {
    fontSize: 16,
  },
  tag: {
    marginLeft: 10,
  },
});

function List() {
  console.log("데이터 확인")
  console.log(NumberListData)
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ backgroundColor: '#FFFFFF' }}>
        {NumberListData.map((item, index) => (
          <View key={index} style={styles.itemWrap}>
            <View style={styles.leftArea}>
              <View style={styles.imgContainer}>
                <Image style={styles.img} source={imageMap[item.photo]} />
              </View>
              <CustomBtn
                title={'전화걸기'}
                background={'#2196F3'}
                border={'#2196F3'}
                fontColor={'#FFFFFF'}
                onPress={() => { Linking.openURL(`tel:${item.number}`); }} />
            </View>
            <View style={styles.rightArea}>
              <View style={styles.labelWrap}>
                <Text style={styles.label}>이름: </Text>
                <Text style={styles.value}>{item.name}</Text>
              </View>
              <View style={styles.labelWrap}>
                <Text style={styles.label}>연락처: </Text>
                <Text style={styles.value}>{item.number}</Text>
              </View>
              <View style={styles.labelWrap}>
                <Text style={styles.label}>음성인식 태그</Text>
              </View>
              <View style={styles.labelWrap}>
                <View style={styles.tag}>
                  {item.tag.map((tagItem, tagIndex) => (
                    <Text key={tagIndex}>{`${tagIndex + 1}. ${tagItem}`}</Text>
                  ))}
                </View>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  )
}

export default List;
