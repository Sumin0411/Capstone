import { StyleSheet, TextInput, Text, View, Button,SafeAreaView ,Image,TouchableOpacity} from 'react-native';
import { AntDesign } from '@expo/vector-icons'; 
import React , {useState} from 'react';
import { inputStyles ,btnStyles } from '../globalStyle'
import CustomBtn from '../components/CustomButton'
import userUser from '../assets/images/photo/icon.png'

const styles = StyleSheet.create({
    userUser: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
    },
    common : {
        backgroundColor : '#FFFFFF',
        flex: 1
    },
    title : {
        fontSize : 24,
        color : '#666666',
        fontWeight: 700,
        padding : 30,
        textAlign : 'center'
    },
    imgArea :{
        height : '50%',  
    },
    inputArea : {
        height : '82%',
    },
    btnArea : {
        height : '18%',
        marginLeft : 15,
        marginRight : 15,
    },
    userUser : {
      padding : 70,
      width : 50,
      height: 50,
      margin : 'auto',
      alignItems : 'center',
    },
    logo: {
      width: 66,
      height: 58,
    },
    mgVtAuto : {
       marginTop : 'auto',
       marginBottom : 'auto',
    },
    innerText :{
        marginLeft:5,
        color: "#666666",
        fontSize:'5',
    }
  });

// function Join({navigation}){
//     const [name, setName] = useState('');
//     const [phoneNumber, setPhoneNumber] = useState('');
//     const [keyword1, setKeyword1] = useState('');
//     const [keyword2, setKeyword2] = useState('');
//     const [keyword3, setKeyword3] = useState('');

//     const setNumberAdd = () => {
//         alert("등록완료!")
//         navigation.push('List')
//     }
    return (
          <SafeAreaView style={{ flex: 1 }}>
            <View style={styles.common}>
              <View style={styles.inputArea}>
                <View style={styles.mgVtAuto}>

                  <View style={inputStyles.wrap}>
                    <Text style={[inputStyles.label, { fontSize: 25 }]} marginTop={15}>
                      연락처
                    </Text>

                  </View>
                  <View style={inputStyles.wrap}>
                    <Text style={[inputStyles.label, { fontSize: 25 }]} marginTop={15}>
                      음성인식 키워드
                      <Text style={[styles.innerText, { fontSize: 10 }]}>
                        {' '}
                        ※ 최대 3개까지 가능합니다.
                      </Text>
                    </Text>
                    <View style={styles.mgVtAuto}>
                      <Text style={[inputStyles.label, { fontSize: 25 }]} marginTop={15}> 프로필 사진</Text>
                      <Image source={userUser} style={styles.userUser} />
                      <Text style={[]}> </Text>
                    </View>
                  </View>
                </View>
              </View>
                <View style={styles.btnArea}>
                    <View style={styles.mgVtAuto}>
                        <CustomBtn
                            title={'등록하기'}
                            background = {'#2196F3'}
                            border={'#2196F3'}
                            fontColor={'#FFFFFF'}
                            onPress={() => setNumberAdd()}/>
                        <CustomBtn
                            title={'취소하기'}
                            background = {'#EEEEEE'}
                            border={'#EEEEEE'}
                            fontColor={'#333333'}
                            onPress={() => navigation.push('List')}/>
                 
                        {/* <Button title="시작하기" onPress={() => navigation.push('Join')}/> */}
                    </View>
                </View>
            </View>
        </SafeAreaView>
       
    );

export default Join