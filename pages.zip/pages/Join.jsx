import { StyleSheet, TextInput, Text, View, Button,SafeAreaView ,Image,TouchableOpacity} from 'react-native';
import { AntDesign } from '@expo/vector-icons'; 
import React , {useState} from 'react';
import { inputStyles ,btnStyles } from '../globalStyle'
import CustomBtn from '../components/CustomButton'


const styles = StyleSheet.create({
    common : {
        backgroundColor : '#FFFFFF',
        flex: 1
    },
    inputArea : {
        height : '43%',
    },
    btnArea : {
        height : '18%',
        marginLeft : 600,
        marginRight : 650,
    },
    logo: {
      width: 66,
      height: 58,
    },
    mgVtAuto : {
       marginTop : 'auto',
       marginBottom : 'auto',
    }
  });

  function Join({ navigation }) {
    const [name, setName] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [password, setPassword] = useState('');
  
    return (
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.common}>
          <View style={styles.inputArea}>
            <View style={styles.mgVtAuto}>
              
              <View style={inputStyles.wrap}>
              <Text style={[inputStyles.label, { fontSize: 40 }]}>첫 번째 질문.</Text>              
              </View>
              <View style={inputStyles.wrap}>
              <Text style={[inputStyles.label, { fontSize: 25 }]}>딸은 보통 여가시간에 뭐 해? </Text>
              <Text style={[inputStyles.label, { fontSize: 15, fontWeight: 'normal' }]}>#1번째 질문 Sep 07, 2023</Text>


                <TextInput
                  style={inputStyles.input}
                  placeholderTextColor={'#666666'}
                  onChangeText={setPhoneNumber}
                  value={phoneNumber}
                  placeholder="이곳을 눌러서 답변을 입력해주세요."
                  />
              </View>
              <View style={inputStyles.wrap}>

              </View>
            </View>
          </View>
                <View style={styles.btnArea}>
                    <View style={styles.mgVtAuto}>
                        <CustomBtn
                            title={'등록하기'}
                            background = {'#0d0000'}
                            border={'#2196F3'}
                            fontColor={'#FFFFFF'}
                            onPress={() => navigation.push('Login')}/>
                          
                    </View>
                </View>
            </View>
        </SafeAreaView>
    )
}

export default Join